package pruebas;

import unojuego.*;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.List;

public class PruebasEspeciales {

    @Test
    public void testCartasEspeciales() {
        // 1. --- CAJA BLANCA (Lógica Interna de Salto) ---
        ManejadorTurnos turnos = new ManejadorTurnos(2);
        CartaAccion salto = new CartaAccion(ColorCarta.ROJO, "Salto");
        salto.aplicarEfecto(turnos, null);
        assertTrue("Caja Blanca: El flag debe activarse", turnos.debeSaltar());

        // 2. --- CAJA NEGRA (Resultado de Reversa) ---
        ManejadorTurnos turnosNegra = new ManejadorTurnos(3); 
        CartaAccion rev = new CartaAccion(ColorCarta.VERDE, "Rev");
        rev.aplicarEfecto(turnosNegra, null);
        turnosNegra.avanzar();
        assertEquals("Caja Negra: El turno debe cambiar de dirección", 2, turnosNegra.getTurnoActual());

        // 3. --- CAJA GRIS (Validación de +2 y +4) ---
        // Preparamos el escenario con jugadores reales
        List<Jugador> jugadores = new ArrayList<>();
        jugadores.add(new Humano("P1"));
        jugadores.add(new Humano("P2"));
        
        // El Gestor de Reglas es el que aplica las penalizaciones
        GestorReglas reglas = new GestorReglas(new Baraja(new PilaDescarte()), new PilaDescarte(), new ManejadorTurnos(2), jugadores, m -> {});
        
        // --- PRUEBA DEL +2 ---
        reglas.penalizarSiguiente(2);
        assertEquals("Caja Gris: El Jugador 2 debe recibir 2 cartas por el +2", 
                     2, jugadores.get(1).getMano().size());

        // --- PRUEBA DEL +4 ---
        // Como el jugador ya tenía 2 cartas, al sumar 4 debe tener 6
        reglas.penalizarSiguiente(4);
        assertEquals("Caja Gris: El Jugador 2 debe acumular 6 cartas en total por el +4", 
                     6, jugadores.get(1).getMano().size());
    }
}
package pruebas;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
    PruebasEspeciales.class,
    PruebasRobustezConsola.class
})
public class SuitePruebas {
    // Esta clase se deja vacía, solo sirve para organizar la ejecución
}
package pruebas;

import unojuego.*;
import org.junit.Test;
import static org.junit.Assert.*;
import java.io.ByteArrayInputStream;

public class PruebasRobustezConsola {

    @Test
    public void testManejoErroresConsola() {
        // --- SIMULACIÓN DE ENTRADA ---
        // Preparamos las respuestas automáticas para las pruebas
        String entradasSimuladas = "abc\n!@#$%\nerror\n";
        System.setIn(new ByteArrayInputStream(entradasSimuladas.getBytes()));
        
        Consola consola = new Consola();

        // --- CAJA BLANCA (Flujo de Excepción) ---
        // Validamos que el bloque catch atrape "abc" y devuelva el valor de seguridad
        int valorSeguro = 10;
        int resultadoBlanca = consola.pedirEntero("abc", valorSeguro); 
        assertEquals("Caja Blanca: Debe retornar el valor por defecto al entrar al catch", 
                     valorSeguro, resultadoBlanca);

        // --- CAJA NEGRA (Robustez del Sistema) ---
        // Validamos estabilidad con símbolos especiales
        int resultadoNegra = consola.pedirEntero("!@#$%", -1);
        assertEquals("Caja Negra: El sistema no debe romperse y retornar -1", 
                     -1, resultadoNegra);

        // --- CAJA GRIS (Estado Post-Error) ---
        // Validamos que el objeto siga vivo tras múltiples errores
        consola.pedirEntero("error", 0);
        assertNotNull("Caja Gris: El objeto consola debe seguir funcional", consola);
    }
}
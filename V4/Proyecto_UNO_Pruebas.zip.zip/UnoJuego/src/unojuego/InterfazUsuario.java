package unojuego;

import java.util.List;

public interface InterfazUsuario extends NotificadorEventos {
    void mostrarMesa(Carta cima, ColorCarta colorActual);
    void mostrarMano(String nombre, List<Carta> mano);
    int pedirEntero(String prompt, int valorPorDefecto);
    String pedirCadena(String prompt);
}
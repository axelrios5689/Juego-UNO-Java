package unojuego;

import java.util.List;

public class GestorReglas {
    private Baraja baraja;
    private PilaDescarte descarte;
    private ManejadorTurnos turnos;
    private List<Jugador> jugadores;
    private NotificadorEventos notificador;

    public GestorReglas(Baraja b, PilaDescarte d, ManejadorTurnos t, List<Jugador> j, NotificadorEventos n) {
        this.baraja = b; this.descarte = d; this.turnos = t; this.jugadores = j; this.notificador = n;
    }

    public void penalizarSiguiente(int cantidad) {
        int indexSig = turnos.getSiguienteTurno();
        Jugador victima = jugadores.get(indexSig);
        notificador.informar("! " + victima.getNombre() + " recibe " + cantidad + " cartas !");
        for (int i = 0; i < cantidad; i++) {
            victima.recibirCarta(baraja.robar());
        }
        turnos.activarSalto(); // El penalizado pierde su turno
    }
}
package unojuego;

public interface NotificadorEventos {
    void informar(String mensaje);
}
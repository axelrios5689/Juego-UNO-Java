package unojuego;

public class CartaNumerica extends Carta {
    public CartaNumerica(ColorCarta color, String valor) { super(color, valor); }
    
    @Override 
    public boolean esCompatible(Carta otra, ColorCarta colorActual) {
        return this.color == colorActual || this.valor.equals(otra.getValor());
    }
    
    @Override 
    public void aplicarEfecto(ManejadorTurnos turnos, GestorReglas reglas) {}
}
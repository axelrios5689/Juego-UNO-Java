package unojuego;

import java.util.ArrayList;
import java.util.List;

public class Juego {
    private List<Jugador> jugadores = new ArrayList<>();
    private Baraja baraja;
    private PilaDescarte descarte = new PilaDescarte();
    private ManejadorTurnos turnos;
    private GestorReglas reglas;
    private InterfazUsuario ui;
    private ColorCarta colorActual;

    public Juego(int numHumanos, int numCPUs, InterfazUsuario ui) {
        this.ui = ui;
        for (int i = 1; i <= numHumanos; i++) jugadores.add(new Humano("Jugador " + i));
        for (int i = 1; i <= numCPUs; i++) jugadores.add(new CPU("Bot " + i));
        
        this.baraja = new Baraja(descarte);
        this.turnos = new ManejadorTurnos(jugadores.size());
        this.reglas = new GestorReglas(baraja, descarte, turnos, jugadores, ui);
        
        jugadores.forEach(j -> { for(int k=0; k<7; k++) j.recibirCarta(baraja.robar()); });
        
        Carta inicial = baraja.robar();
        while (inicial instanceof CartaComodin) { baraja.devolverAlFondo(inicial); inicial = baraja.robar(); }
        descarte.dejarEnMesa(inicial);
        colorActual = inicial.getColor();
    }

    public void iniciar() {
        while (true) {
            if (turnos.debeSaltar()) { turnos.avanzar(); continue; }
            
            Jugador actual = jugadores.get(turnos.getTurnoActual());
            ui.informar("\n>>> TURNO DE: " + actual.getNombre());
            ui.mostrarMesa(descarte.verCima(), colorActual);
            
            int eleccion = actual.elegirJugada(descarte.verCima(), colorActual, ui);
            procesarJugada(actual, eleccion);
            
            if (actual.cantidadCartas() == 0) {
                ui.informar("¡GANADOR: " + actual.getNombre() + "!");
                break;
            }
            turnos.avanzar();
        }
    }

    private void procesarJugada(Jugador j, int idx) {
        if (idx >= 0 && idx < j.getMano().size()) {
            Carta elegida = j.getMano().get(idx);
            if (elegida.esCompatible(descarte.verCima(), colorActual)) {
                j.getMano().remove(idx);
                descarte.dejarEnMesa(elegida);
                colorActual = elegida.getColor();
                if (elegida instanceof CartaComodin) manejarComodin(j);
                elegida.aplicarEfecto(turnos, reglas);
                return;
            }
        }
        ui.informar(j.getNombre() + " roba carta.");
        j.recibirCarta(baraja.robar());
    }

    private void manejarComodin(Jugador j) {
        if (j instanceof Humano) {
            String c = ui.pedirCadena("Elige color (R,V,A,M): ").toUpperCase();
            colorActual = switch(c) {
                case "V" -> ColorCarta.VERDE; case "A" -> ColorCarta.AZUL;
                case "M" -> ColorCarta.AMARILLO; default -> ColorCarta.ROJO;
            };
        } else { colorActual = ColorCarta.values()[(int)(Math.random()*4)]; }
    }
}
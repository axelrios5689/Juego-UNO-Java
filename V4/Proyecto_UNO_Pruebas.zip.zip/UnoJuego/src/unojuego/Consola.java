package unojuego;

import java.util.Scanner;
import java.util.stream.IntStream;

public class Consola implements InterfazUsuario {
    private Scanner sc = new Scanner(System.in);

    @Override
    public void informar(String mensaje) {
        System.out.println(mensaje);
    }

    @Override
    public void mostrarMesa(Carta cima, ColorCarta colorActual) {
        System.out.println("\n------------------------------------------------");
        System.out.println("CARTA EN MESA:");
        IntStream.range(0, 7).forEach(i -> System.out.println(cima.getLinea(i)));
        String valMesa = cima.getValor().equals("Color") ? "comodin" : cima.getValor();
        System.out.println("ESTADO -> Color: " + colorActual + " | Valor: " + valMesa);
    }

    @Override
    public void mostrarMano(String nombre, java.util.List<Carta> mano) {
        // ... (el código de mostrarMano que tienes en tu original)
    }

    @Override
    public int pedirEntero(String prompt, int valorPorDefecto) {
        System.out.print(prompt);
        try { 
            return Integer.parseInt(sc.nextLine()); 
        } catch(Exception e) { 
            return valorPorDefecto; // Este es el punto que probaremos
        }
    }

    @Override
    public String pedirCadena(String prompt) {
        System.out.print(prompt);
        return sc.nextLine();
    }
}
package unojuego;

public class ManejadorTurnos {
    private int turnoActual = 0; 
    private int direccion = 1;   
    private boolean saltarProximo = false; 
    private int cantidadJugadores;

    public ManejadorTurnos(int cantidadJugadores) { this.cantidadJugadores = cantidadJugadores; }
    public int getTurnoActual() { return turnoActual; }
    public int getSiguienteTurno() { return (turnoActual + (direccion + cantidadJugadores)) % cantidadJugadores; }
    public void avanzar() { turnoActual = getSiguienteTurno(); }
    public void activarSalto() { saltarProximo = true; }

    public boolean debeSaltar() {
        if (saltarProximo) {
            saltarProximo = false;
            return true;
        }
        return false;
    }

    public void invertirDireccion() {
        if (cantidadJugadores == 2) activarSalto(); 
        else direccion *= -1;
    }
}
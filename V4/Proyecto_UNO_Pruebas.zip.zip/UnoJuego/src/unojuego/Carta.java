package unojuego;

public abstract class Carta {
    protected ColorCarta color;
    protected String valor;

    // ESTE ES EL CONSTRUCTOR QUE FALTA
    public Carta(ColorCarta color, String valor) {
        this.color = color;
        this.valor = valor;
    }

    public ColorCarta getColor() { return color; }
    public String getValor() { return valor; }

    public abstract boolean esCompatible(Carta otra, ColorCarta colorActual);
    public abstract void aplicarEfecto(ManejadorTurnos turnos, GestorReglas reglas);

    // Método para el dibujo de la carta
    public String getLinea(int linea) {
        String cCode = getColorCode(color);
        String r = "\u001B[0m";
        String v = String.format("%-2s", valor);
        
        return switch (linea) {
            case 0 -> cCode + ".-------." + r;
            case 1 -> cCode + "| " + v + "    |" + r;
            case 2 -> cCode + "|       |" + r;
            case 3 -> cCode + "|   " + v + "  |" + r;
            case 4 -> cCode + "|       |" + r;
            case 5 -> cCode + "|    " + v + " |" + r;
            case 6 -> cCode + "'-------'" + r;
            default -> "";
        };
    }

    private String getColorCode(ColorCarta c) {
        return switch (c) {
            case ROJO -> "\u001B[31m";
            case VERDE -> "\u001B[32m";
            case AZUL -> "\u001B[34m";
            case AMARILLO -> "\u001B[33m";
            case NEGRO -> "\u001B[37m";
        };
    }
}
package unojuego;

import java.util.ArrayList;
import java.util.List;

public abstract class Jugador {
    protected String nombre;
    protected List<Carta> mano = new ArrayList<>();

    public Jugador(String nombre) { this.nombre = nombre; }
    public String getNombre() { return nombre; }
    public List<Carta> getMano() { return mano; }
    public void recibirCarta(Carta c) { if (c != null) mano.add(c); }
    public int cantidadCartas() { return mano.size(); }
    
    public abstract int elegirJugada(Carta cima, ColorCarta colorActual, InterfazUsuario ui);
}
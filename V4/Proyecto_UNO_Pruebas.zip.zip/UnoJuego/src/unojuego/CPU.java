package unojuego;

public class CPU extends Jugador {
    public CPU(String nombre) { super(nombre); }

    @Override
    public int elegirJugada(Carta cima, ColorCarta colorActual, InterfazUsuario ui) {
        for (int i = 0; i < mano.size(); i++) {
            if (mano.get(i).esCompatible(cima, colorActual)) return i;
        }
        return -1; // Robar si no tiene nada compatible
    }
}
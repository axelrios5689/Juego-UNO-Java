package unojuego;

import java.util.Stack;
import java.util.Collection;

public class PilaDescarte {
    private Stack<Carta> pila = new Stack<>();

    public void dejarEnMesa(Carta c) { pila.push(c); }
    public Carta verCima() { return pila.peek(); }
    public int size() { return pila.size(); }
    public Carta removerCima() { return pila.pop(); }
    public void vaciar() { pila.clear(); }
    public Collection<Carta> obtenerTodas() { return pila; }
}
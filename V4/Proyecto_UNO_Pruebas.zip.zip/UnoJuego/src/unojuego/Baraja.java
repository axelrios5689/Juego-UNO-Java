package unojuego;

import java.util.*;
import java.util.stream.IntStream;

public class Baraja {
    private LinkedList<Carta> mazo = new LinkedList<>();
    private PilaDescarte descarte;

    public Baraja(PilaDescarte descarte) {
        this.descarte = descarte;
        ColorCarta[] colores = {ColorCarta.ROJO, ColorCarta.VERDE, ColorCarta.AZUL, ColorCarta.AMARILLO};
        
        Arrays.stream(colores).forEach(c -> {
            mazo.add(new CartaNumerica(c, "0"));
            IntStream.rangeClosed(1, 9).forEach(i -> {
                mazo.add(new CartaNumerica(c, String.valueOf(i)));
                mazo.add(new CartaNumerica(c, String.valueOf(i)));
            });
            IntStream.range(0, 2).forEach(i -> {
                mazo.add(new CartaAccion(c, "Salto"));
                mazo.add(new CartaAccion(c, "Rev"));
                mazo.add(new CartaAccion(c, "+2"));
            });
        });
        
        IntStream.range(0, 4).forEach(i -> {
            mazo.add(new CartaComodin("Color"));
            mazo.add(new CartaComodin("+4"));
        });
        
        Collections.shuffle(mazo);
    }

    public Carta robar() {
        if (mazo.isEmpty()) {
            if (descarte.size() <= 1) return null;
            Carta cima = descarte.removerCima();
            mazo.addAll(descarte.obtenerTodas());
            descarte.vaciar();
            descarte.dejarEnMesa(cima);
            Collections.shuffle(mazo);
        }
        return mazo.pollFirst();
    }

    public void devolverAlFondo(Carta c) { mazo.addLast(c); }
}
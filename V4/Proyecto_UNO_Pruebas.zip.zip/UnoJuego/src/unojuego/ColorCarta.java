package unojuego;

public enum ColorCarta { 
    ROJO, VERDE, AZUL, AMARILLO, NEGRO 
}
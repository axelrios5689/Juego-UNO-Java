package unojuego;

public class CartaComodin extends Carta {
    public CartaComodin(String valor) { super(ColorCarta.NEGRO, valor); }
    
    @Override 
    public boolean esCompatible(Carta otra, ColorCarta colorActual) { return true; }
    
    @Override 
    public void aplicarEfecto(ManejadorTurnos turnos, GestorReglas reglas) {
        if (valor.equals("+4")) reglas.penalizarSiguiente(4);
    }
}
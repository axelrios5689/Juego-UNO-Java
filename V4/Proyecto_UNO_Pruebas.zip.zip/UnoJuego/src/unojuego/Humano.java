package unojuego;

public class Humano extends Jugador {
    public Humano(String nombre) { super(nombre); }

    @Override
    public int elegirJugada(Carta cima, ColorCarta colorActual, InterfazUsuario ui) {
        ui.mostrarMano(nombre, mano);
        return ui.pedirEntero("Elige el indice de la carta a jugar (o -1 para robar): ", -1);
    }
}
package unojuego;

public class UnoJuego {
    public static void main(String[] args) {
        InterfazUsuario ui = new Consola();
        ui.informar("--- BIENVENIDO A UNO (Ingeniería de Software) ---");
        Juego partida = new Juego(1, 2, ui); // 1 humano contra 2 bots
        partida.iniciar();
    }
}
package unojuego;

public class CartaAccion extends Carta {
    public CartaAccion(ColorCarta color, String valor) { 
        super(color, valor); 
    }
    
    @Override 
    public boolean esCompatible(Carta otra, ColorCarta colorActual) {
        return this.color == colorActual || this.valor.equals(otra.getValor());
    }
    
    @Override 
    public void aplicarEfecto(ManejadorTurnos turnos, GestorReglas reglas) {
        switch (valor) {
            case "Salto" -> turnos.activarSalto();
            case "Rev" -> turnos.invertirDireccion();
            case "+2" -> reglas.penalizarSiguiente(2);
        }
    }
}